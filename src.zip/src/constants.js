export const HOME_URL = "https://forum.centromics.org/";
export const SITE_TAG = "centromics";
