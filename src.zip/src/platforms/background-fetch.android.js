// let's not use BackgroundFetch for Android
// it asks for odd permissions
