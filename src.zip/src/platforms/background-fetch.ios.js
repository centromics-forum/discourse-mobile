import BackgroundFetch from 'react-native-background-fetch';

export default BackgroundFetch;
