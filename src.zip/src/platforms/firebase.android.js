import firebase from '@react-native-firebase/app';
import '@react-native-firebase/messaging';

export default firebase.messaging();
