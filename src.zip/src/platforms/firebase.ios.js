// iOS does not use Firebase
